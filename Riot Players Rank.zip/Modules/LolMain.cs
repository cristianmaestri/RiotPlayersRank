﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace $safeprojectname$.Modules
{
    
    public class LolMain
    {
        private string tokenLol = "?api_key=RGAPI-e0c8afd5-4e6f-44d9-ab9f-ee68908901cc";
        private string SummonerName = "OSWALDIR";
        private string UrlGGetId = "https://br1.api.riotgames.com/lol/summoner/v4/summoners/by-name" + SummonerName;
        
        

    }

}
